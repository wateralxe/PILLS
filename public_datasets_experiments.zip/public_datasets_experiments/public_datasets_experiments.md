# public_datasets_experiments

This archive contains AUAF and both Criteo datasets. Criteo DAC and Criteo Attribution are different public datasets from the same company, Criteo.

## Dataset locations

All paths are relative to this README; an asterisk matches directory suffixes.

| Dataset | Input directories | Experiment directories |
|---|---|---|
| AUAF | `data/instances/AUAF_native_seed*` | `results/budget1000/runs/AUAF_native_seed*` |
| Criteo DAC, 100K | `data/instances/Criteo_load*_seed*` | `results/budget1000/runs/Criteo_load*_seed*` |
| Criteo Attribution, 500K | `data/topvenue_instances/CriteoAttribution_500K-disjoint_load*_seed*` | `results/attribution1000/runs/CriteoAttribution_500K-disjoint_load*_seed*` |

## Associated papers

- **AUAF:** [An Adaptive Unified Allocation Framework for Guaranteed Display Advertising](https://doi.org/10.1145/3488560.3498500), **WSDM 2022**. Public data: [AUAF authors' repository](https://github.com/cxmlxq/AUAF).
- **Criteo DAC (100K):** [xDeepFM: Combining Explicit and Implicit Feature Interactions for Recommender Systems](https://www.microsoft.com/en-us/research/wp-content/uploads/2019/07/ACM_Proceding_p1754-lian.pdf), **KDD 2018**; a representative paper using the [Criteo DAC dataset](https://ailab.criteo.com/ressources/).
- **Criteo Attribution (500K):** original dataset-release paper: [Attribution Modeling Increases Efficiency of Bidding in Display Advertising](https://arxiv.org/abs/1707.06409), **AdKDD / TargetAd Workshop at KDD 2017**. Representative later paper using the dataset: [Multi-task Offline Reinforcement Learning for Online Advertising in Recommender Systems](https://arxiv.org/abs/2506.23090), **KDD 2025**. Public data: [Criteo Attribution dataset](https://huggingface.co/datasets/criteo/criteo-attribution-dataset).

The archive includes processed input files, allocation CSVs, result JSONs and retained PILLS execution logs. Raw Criteo downloads and caches are omitted to keep the archive compact.

## Verification

Check file integrity after extraction:

```bash
sha256sum -c SHA256SUMS
python3 scripts/verify_experiment_bundle.py
```

To check saved allocations and metrics:

```bash
python3 scripts/verify_experiment_bundle.py --metrics
```

PILLS source: https://anonymous.4open.science/r/PILLS-C1F0
