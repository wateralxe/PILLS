"""Run original PILLS, integerized published HWM, and SCIP on identical instances."""
import argparse
import csv
import json
import math
import os
import subprocess
import sys
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / ".deps501"))
import numpy as np
from pyscipopt import Model, quicksum

PILLS_OFF = ROOT / "vendor/PILLS/PILLS-offline/src/main"
PILLS_ON = ROOT / "vendor/PILLS/PILLS-online/src/main"
PENALTY = 10000


class Instance:
    def __init__(self, path):
        self.path = Path(path)
        self.meta = json.loads((self.path / "instance.json").read_text())
        self.n_off = self.meta["n_offline"]
        self.n_on = self.meta["n_online"]
        self.n = len(self.meta["supplies"])
        self.cap = np.array([s["capacity"] for s in self.meta["supplies"]], dtype=np.int64)
        self.heat = np.array([s["heat"] for s in self.meta["supplies"]])
        self.demand = np.array(self.meta["demands"], dtype=np.int64)
        self.edges = [set(map(int, s["eligible"])) for s in self.meta["supplies"]]
        self.neighbors = [np.array([i for i, e in enumerate(self.edges) if j in e], dtype=np.int64)
                          for j in range(self.n_off + self.n_on)]
        self.sid_idx = {s["sid"]: i for i, s in enumerate(self.meta["supplies"])}

    def check(self, allocation, phase="offline", previous=None):
        assert np.issubdtype(allocation.dtype, np.integer)
        assert allocation.shape == (self.n, self.n_off + self.n_on)
        assert (allocation >= 0).all(), phase
        assert (allocation.sum(axis=1) <= self.cap).all(), phase
        for i, row in enumerate(allocation):
            assert all(int(j) in self.edges[i] for j in np.nonzero(row)[0]), (phase, i)
        if phase == "offline":
            assert (allocation.sum(axis=0)[:self.n_off] <= self.demand).all()
            assert not allocation[:, self.n_off:].any()
        if previous is not None:
            assert (allocation.sum(axis=0) >= previous.sum(axis=0)).all(), "Existing contract delivery decreased"

    def metrics(self, allocation, phase="offline", residual_initial=None, accepted=None):
        residual = self.cap - allocation.sum(axis=1)
        totals = allocation.sum(axis=0)
        ud = np.maximum(0, self.demand - totals[:self.n_off])
        if phase == "offline":
            return {"obj": float(np.dot(self.heat, residual.astype(float)**2) - PENALTY*ud.sum()),
                    "ud": float(ud.sum()/self.demand.sum()), "underdelivered": int(ud.sum()),
                    "residual": int(residual.sum()), "allocated": int(totals.sum())}
        online_ud = np.maximum(0, np.asarray(accepted)-totals[self.n_off:])
        objective = int(totals[self.n_off:].sum()) - PENALTY*int(ud.sum()+online_ud.sum())
        return {"obj": objective, "unit": objective/residual_initial if residual_initial else None,
                "allocated_online": int(totals[self.n_off:].sum()), "underdelivered_offline": int(ud.sum()),
                "underdelivered_online": int(online_ud.sum()), "residual_initial": int(residual_initial),
                "residual_final": int(residual.sum())}


def blank(ins):
    return np.zeros((ins.n, ins.n_off+ins.n_on), dtype=np.int64)


def read_allocation(ins, filename):
    allocation = blank(ins)
    with Path(filename).open() as f:
        reader = csv.reader(f)
        next(reader)
        for sid, demand, pv in reader:
            pv = int(pv)
            if pv:
                allocation[ins.sid_idx[sid], int(demand)] += pv
    return allocation


def write_allocation(ins, allocation, filename):
    with Path(filename).open("w") as f:
        w = csv.writer(f)
        w.writerow(["SID", "Demand", "Allocated PV"])
        for i, j in zip(*np.nonzero(allocation)):
            w.writerow([ins.meta["supplies"][i]["sid"], j, allocation[i,j]])


def hwm(ins):
    start = time.monotonic()
    allocation = blank(ins)
    remaining = ins.cap.copy()
    order = sorted(range(ins.n_off), key=lambda j: (ins.cap[ins.neighbors[j]].sum(), j))
    rates = {}
    for j in order:
        neighbors = ins.neighbors[j]
        r, c = remaining[neighbors], ins.cap[neighbors]
        target = min(int(ins.demand[j]), int(r.sum()))
        if target == int(r.sum()):
            integers = r.copy()
            alpha = 1.0
        else:
            lo, hi = 0.0, 1.0
            for _ in range(64):
                mid = (lo+hi)/2
                if np.minimum(r, c*mid).sum() < target:
                    lo = mid
                else:
                    hi = mid
            alpha = hi
            fractional = np.minimum(r, c*alpha)
            integers = np.minimum(r, np.floor(fractional+1e-10).astype(np.int64))
            left = target-int(integers.sum())
            eligible = [k for k in range(len(neighbors)) if integers[k] < r[k]]
            priority = sorted(eligible, key=lambda k: (-(fractional[k]-integers[k]), int(neighbors[k])))
            for k in priority[:left]:
                integers[k] += 1
        assert int(integers.sum()) == target
        allocation[neighbors,j] = integers
        remaining[neighbors] -= integers
        rates[str(j)] = alpha
    ins.check(allocation)
    return allocation, {"wall_seconds": time.monotonic()-start, "threads": 1,
                        "order": order, "rates": rates, "integerization": "largest remainder per contract"}


def pills_offline(ins, out, budget):
    start = time.monotonic()
    prefix = out / "pills"
    with (out / "pills_offline.log").open("w") as log:
        command = [str(PILLS_OFF), str(ins.path/"demand.txt"), str(ins.path/"supply.txt"),
                   str(ins.path/"heat.txt"), str(prefix), "__NO_ONLINE_QUERY__"]
        process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT)
        try:
            process.wait(timeout=budget)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()
            raise RuntimeError("PILLS exceeded external offline budget; no partial output accepted")
        if process.returncode:
            raise RuntimeError("PILLS failed: " + str(out / "pills_offline.log"))
    files = sorted(out.glob("pills_component_*_offline.csv")) or [out/"pills_offline.csv"]
    allocation = blank(ins)
    for f in files:
        allocation += read_allocation(ins, f)
    ins.check(allocation)
    write_allocation(ins, allocation, out/"PILLS_offline.csv")
    return allocation, {"wall_seconds": time.monotonic()-start, "threads": 32,
                        "source": "original anonymous repository, no source changes",
                        "command": command, "budget_seconds": budget}


def scip_offline(ins, out, initial, budget):
    if (ins.cap == 1).all():
        return scip_unit_offline(ins,out,initial,budget)
    start = time.monotonic()
    model = Model("GD_offline_"+ins.path.name)
    model.hideOutput()
    (out/"scip.log").write_text("")
    model.setLogfile(str(out/"scip.log"))
    model.setIntParam("parallel/maxnthreads", 1)
    model.setIntParam("lp/threads", 1)
    model.setIntParam("misc/usesymmetry", getattr(ins,"scip_symmetry",7))
    model.setRealParam("limits/gap", 0.0)
    model.setIntParam("randomization/randomseedshift", int(ins.meta["seed"]))
    x, levels, u = {}, {}, []
    rewards = []
    for i in range(ins.n):
        cap = int(ins.cap[i])
        for j in sorted(ins.edges[i]):
            if j < ins.n_off:
                x[i,j] = model.addVar(name="x_{}_{}".format(i,j), vtype="I", lb=0,
                                       ub=int(min(cap,ins.demand[j])))
        if cap == 1:
            levels[i] = model.addVar(name="r_{}".format(i), vtype="B")
            residual = levels[i]
            rewards.append(float(ins.heat[i])/PENALTY*residual)
        else:
            # One-hot encoding of every possible integer residual. This is
            # exactly r^2, without a continuous/nonconvex nonlinear constraint.
            levels[i] = [model.addVar(name="z_{}_{}".format(i,k),vtype="B") for k in range(cap+1)]
            model.addCons(quicksum(levels[i]) == 1)
            residual = quicksum(k*z for k,z in enumerate(levels[i]))
            rewards.append(quicksum(float(ins.heat[i])/PENALTY*k*k*z for k,z in enumerate(levels[i])))
        model.addCons(residual + quicksum(x[i,j] for j in ins.edges[i] if j < ins.n_off) == cap)
    for j in range(ins.n_off):
        u.append(model.addVar(name="u_{}".format(j), lb=0, ub=int(ins.demand[j])))
        model.addCons(quicksum(x[int(i),j] for i in ins.neighbors[j])+u[j] == int(ins.demand[j]))
    model.setObjective(quicksum(rewards)-quicksum(u), "maximize")
    solution = model.createSol()
    residual = ins.cap-initial.sum(axis=1)
    totals = initial.sum(axis=0)
    for edge, variable in x.items():
        model.setSolVal(solution,variable,int(initial[edge]))
    for i in range(ins.n):
        if ins.cap[i] == 1:
            model.setSolVal(solution,levels[i],int(residual[i]))
        else:
            for k,z in enumerate(levels[i]):
                model.setSolVal(solution,z,int(k==residual[i]))
    for j in range(ins.n_off):
        model.setSolVal(solution,u[j],int(ins.demand[j]-totals[j]))
    warmstart_accepted = bool(model.addSol(solution, free=True))
    model.writeProblem(str(out/"scip_model.cip"), verbose=False)
    construction = time.monotonic()-start
    model.setRealParam("limits/time", max(0.01,budget-construction))
    model.writeParams(str(out/"scip_settings.set"))
    model.optimize()
    best = model.getBestSol()
    if best is None:
        raise RuntimeError("No SCIP incumbent despite supplied feasible solution")
    allocation = blank(ins)
    for edge, variable in x.items():
        value = model.getSolVal(best,variable)
        assert abs(value-round(value)) < 1e-4
        allocation[edge] = round(value)
    ins.check(allocation)
    recalculated = ins.metrics(allocation)["obj"]
    reported = float(model.getObjVal())*PENALTY
    assert math.isclose(recalculated, reported, rel_tol=1e-5, abs_tol=0.1), (recalculated,reported)
    assert recalculated + 0.1 >= ins.metrics(initial)["obj"], "SCIP lost its HWM incumbent"
    metadata = {"wall_seconds": time.monotonic()-start, "construction_seconds": construction,
                "solve_seconds": model.getSolvingTime(), "status": str(model.getStatus()),
                "gap": float(model.getGap()), "primal_bound": reported,
                "dual_bound": float(model.getDualbound())*PENALTY,
                "nodes": int(model.getNNodes()), "warmstart": "HWM integer solution",
                "warmstart_accepted": warmstart_accepted,
                "scip_version": "9.0.1",
                "pyscipopt_version": "5.0.1", "threads": 1, "parallel_maxnthreads": 1,
                "budget_seconds": budget, "objective_scale": PENALTY,
                "symmetry_setting": getattr(ins,"scip_symmetry",7),
                "formulation": "exact MILP: binary one-hot residual k=0..c; reward sum_k (w/p)*k^2*z_k; capacity-1 reward linear; maximize reward-sum(u)",
                "formulation_reason": "bundled SCIP 9.0 and 9.1 crashed on continuous nonlinear hypograph pilots; no approximation used"}
    write_allocation(ins,allocation,out/"SCIP_offline.csv")
    model.freeProb()
    return allocation, metadata


def scip_unit_offline(ins, out, initial, budget):
    """Capacity-one case is an exact weighted bipartite network-flow model."""
    start = time.monotonic()
    model = Model("GD_unit_capacity_"+ins.path.name)
    model.hideOutput()
    (out/"scip.log").write_text("")
    model.setLogfile(str(out/"scip.log"))
    model.setIntParam("parallel/maxnthreads",1)
    model.setIntParam("lp/threads",1)
    model.setIntParam("misc/usesymmetry",getattr(ins,"scip_symmetry",7))
    model.setRealParam("limits/gap",0.0)
    model.setIntParam("randomization/randomseedshift",int(ins.meta["seed"]))
    x = {}
    for i in range(ins.n):
        for j in sorted(ins.edges[i]):
            if j<ins.n_off:
                # Explicit integrality avoids fractional incumbent reconstruction
                # after SCIP's continuous aggregation, despite the TU structure.
                x[i,j] = model.addVar(name="x_{}_{}".format(i,j),lb=0,ub=1,vtype="B")
        neighbors = [x[i,j] for j in ins.edges[i] if j<ins.n_off]
        if len(neighbors)>1:
            model.addCons(quicksum(neighbors)<=1)
    for j in range(ins.n_off):
        model.addCons(quicksum(x[int(i),j] for i in ins.neighbors[j])<=int(ins.demand[j]))
    # r^2=r, u=d-delivered; eliminate both without changing the objective.
    constant = float(ins.heat.sum())/PENALTY-int(ins.demand.sum())
    model.setObjective(constant+quicksum((1.0-float(ins.heat[i])/PENALTY)*v for (i,j),v in x.items()),"maximize")
    sol = model.createSol()
    for edge,v in x.items():model.setSolVal(sol,v,int(initial[edge]))
    warmstart = bool(model.addSol(sol,free=True))
    model.writeProblem(str(out/"scip_model.cip"),verbose=False)
    construction = time.monotonic()-start
    model.setRealParam("limits/time",max(0.01,budget-construction))
    model.writeParams(str(out/"scip_settings.set"))
    model.optimize()
    best = model.getBestSol()
    if best is None:raise RuntimeError("SCIP unit-capacity LP has no solution")
    allocation = blank(ins)
    for edge,v in x.items():
        value = model.getSolVal(best,v)
        assert abs(value-round(value))<1e-4,(edge,value,"SCIP incumbent must be integral")
        allocation[edge] = round(value)
    ins.check(allocation)
    reported = float(model.getObjVal())*PENALTY
    actual = ins.metrics(allocation)["obj"]
    assert math.isclose(actual,reported,rel_tol=1e-8,abs_tol=0.1),(actual,reported)
    assert actual+0.1>=ins.metrics(initial)["obj"]
    metadata = {"wall_seconds":time.monotonic()-start,"construction_seconds":construction,
                "solve_seconds":model.getSolvingTime(),"status":str(model.getStatus()),"gap":float(model.getGap()),
                "primal_bound":reported,"dual_bound":float(model.getDualbound())*PENALTY,
                "nodes":int(model.getNNodes()),"warmstart":"HWM integer solution","warmstart_accepted":warmstart,
                "scip_version":"9.0.1","pyscipopt_version":"5.0.1","threads":1,"parallel_maxnthreads":1,
                "budget_seconds":budget,"objective_scale":PENALTY,
                "symmetry_setting":getattr(ins,"scip_symmetry",7),
                "formulation":"exact binary unit-capacity network-flow MILP: eliminate residual/underdelivery; maximize constant+sum_(i,j)(1-w_i/p)*x_ij; preserve original integer allocations explicitly",
                "integrality_check":"SCIP integer incumbent values within 1e-4 of integers; cast to integers and independently validate all allocations"}
    write_allocation(ins,allocation,out/"SCIP_offline.csv")
    model.freeProb()
    return allocation,metadata


def online_fifo(ins, initial):
    allocation = initial.copy()
    residual = ins.cap - allocation.sum(axis=1)
    gains = []
    for j in range(ins.n_off,ins.n_off+ins.n_on):
        neighbors = ins.neighbors[j]
        gain = int(residual[neighbors].sum())
        allocation[neighbors,j] += residual[neighbors]
        residual[neighbors] = 0
        gains.append(gain)
    ins.check(allocation, "online", initial)
    return allocation, gains


def online_pills(ins, initial, out, name, budget):
    allocation = initial.copy()
    accepted = []
    durations = []
    work = out/name
    work.mkdir(exist_ok=True)
    before_path = work/"state.csv"
    next_path = work/"next.csv"
    demand_path = work/"existing_demand.txt"
    query_path = work/"query.txt"
    write_allocation(ins,allocation,before_path)
    with (work/"online.log").open("w") as log:
        for j in range(ins.n_off,ins.n_off+ins.n_on):
            # Singleton call: original C++ batch API is driven sequentially, preserving prior contracts.
            demand_path.write_text((ins.path/"demand.txt").read_text()+"".join(
                "{}`{}\n".format(ins.n_off+k,g) for k,g in enumerate(accepted)))
            query_path.write_text("{}`0\n".format(j))
            command = [str(PILLS_ON), str(demand_path), str(ins.path/"supply.txt"), str(before_path),
                       str(query_path), str(next_path), str(budget)]
            start = time.monotonic()
            subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=budget+5)
            durations.append(time.monotonic()-start)
            updated = read_allocation(ins,next_path)
            ins.check(updated,"online",allocation)
            accepted.append(int(updated[:,j].sum()))
            allocation = updated
            next_path.replace(before_path)
    (work/"trace.json").write_text(json.dumps({"accepted":accepted,"wall_seconds":durations}))
    return allocation, accepted, durations


def run_instance(path, offline_budget, online_budget, force=False, results_root=None, scip_symmetry=7):
    ins = Instance(path)
    ins.scip_symmetry = scip_symmetry
    results_root = Path(results_root) if results_root else ROOT / "results"
    out = results_root / "runs" / ins.path.name
    out.mkdir(parents=True,exist_ok=True)
    if (out/"result.json").exists() and not force:
        existing = json.loads((out/"result.json").read_text())
        assert existing["offline"]["SCIP"]["budget_seconds"] == offline_budget, "Existing result has a different offline budget; select another results root"
        assert existing["offline"]["PILLS"]["budget_seconds"] == offline_budget
        assert existing["offline"]["SCIP"].get("symmetry_setting",7)==scip_symmetry, "SCIP symmetry settings differ; use a separate results root or force"
        assert all(row.get("budget_per_query_seconds", online_budget) == online_budget for row in existing["online"].values())
        return existing
    started = time.monotonic()
    hwm_alloc,hwm_meta = hwm(ins)
    write_allocation(ins,hwm_alloc,out/"HWM_offline.csv")
    pills_alloc,pills_meta = pills_offline(ins,out,offline_budget)
    scip_alloc,scip_meta = scip_offline(ins,out,hwm_alloc,offline_budget)
    offline = {}
    for name,allocation,metadata in [("HWM",hwm_alloc,hwm_meta),("PILLS",pills_alloc,pills_meta),("SCIP",scip_alloc,scip_meta)]:
        offline[name] = dict(ins.metrics(allocation),**metadata)
    (out/"offline_result.json").write_text(json.dumps(offline,indent=2))
    print("OFFLINE DONE",ins.path.name,"SCIP",scip_meta["status"],"budget",offline_budget,flush=True)
    online = {}
    for method,base in [("SCIP",scip_alloc),("HWM",hwm_alloc),("PILLS",pills_alloc)]:
        residual_initial = int((ins.cap-base.sum(axis=1)).sum())
        if method != "PILLS":
            t0 = time.monotonic()
            allocation,accepted = online_fifo(ins,base)
            name = method+"-FIFO"
            online[name] = dict(ins.metrics(allocation,"online",residual_initial,accepted),
                                gains=accepted,wall_seconds=time.monotonic()-t0,threads=1)
            write_allocation(ins,allocation,out/(name+"_final.csv"))
        name = method+"-PILLS"
        allocation,accepted,durations = online_pills(ins,base,out,name,online_budget)
        online[name] = dict(ins.metrics(allocation,"online",residual_initial,accepted),
                            gains=accepted,wall_seconds=sum(durations),threads=1,
                            max_query_wall_seconds=max(durations),budget_per_query_seconds=online_budget)
        write_allocation(ins,allocation,out/(name+"_final.csv"))
    # Ties count for every method reaching the maximum; also retain strict and nonzero counts.
    all_gains = np.array([row["gains"] for row in online.values()])
    best = all_gains.max(axis=0)
    winners = all_gains == best
    for k,row in enumerate(online.values()):
        row["top"] = int(winners[k].sum())
        row["top_strict"] = int((winners[k] & (winners.sum(axis=0)==1)).sum())
        row["top_nonzero"] = int((winners[k] & (best>0)).sum())
        row["zero_tied_requests"] = int((best==0).sum())
    result = {"instance": ins.path.name,"platform":ins.meta["platform"],"load":ins.meta["load"],
              "seed":ins.meta["seed"],"supply_nodes":ins.n,"capacity":int(ins.cap.sum()),
              "demand":int(ins.demand.sum()),"n_offline":ins.n_off,"n_online":ins.n_on,
              "offline":offline,"online":online,"total_wall_seconds":time.monotonic()-started,
              "validation":"every allocation checked for integer/nonnegative/eligible/capacity; every online step preserves all prior deliveries"}
    result["instance_path"] = str(ins.path)
    result["offline_budget_seconds"] = offline_budget
    result["online_budget_seconds"] = online_budget
    result["dataset_case"] = ins.meta.get("dataset_case", ins.meta["platform"]+"-original")
    result["raw_records"] = ins.meta.get("records_used")
    result["scenario"] = ins.meta.get("scenario", "semi-synthetic")
    (out/"result.json").write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print("DONE",ins.path.name,"SCIP",scip_meta["status"],"offline obj",
          {k:round(v["obj"],2) for k,v in offline.items()},"online top",{k:v["top"] for k,v in online.items()},flush=True)
    return result


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--instances",nargs="*",default=[])
    p.add_argument("--workers",type=int,default=2)
    p.add_argument("--offline-budget",type=int,default=1000)
    p.add_argument("--online-budget",type=int,default=60)
    p.add_argument("--force",action="store_true")
    p.add_argument("--results-root",type=Path,default=ROOT/"results")
    p.add_argument("--scip-symmetry",type=int,choices=[0,7],default=7)
    args = p.parse_args()
    paths = [Path(v).resolve() for v in args.instances] if args.instances else sorted((ROOT/"data/instances").iterdir())
    failures = []
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        futures = {pool.submit(run_instance,path,args.offline_budget,args.online_budget,args.force,args.results_root,args.scip_symmetry):path for path in paths}
        for future in as_completed(futures):
            try:
                future.result()
            except Exception as e:
                import traceback
                print("FAILED",futures[future],repr(e),flush=True)
                traceback.print_exc()
                failures.append({"instance":str(futures[future]),"error":repr(e)})
    args.results_root.mkdir(parents=True,exist_ok=True)
    (args.results_root/"failures.json").write_text(json.dumps(failures,indent=2))
    sys.exit(bool(failures))
