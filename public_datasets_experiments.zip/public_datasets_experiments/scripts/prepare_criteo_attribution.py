"""Prepare five disjoint public-impression blocks before method evaluation."""
import gzip
import hashlib
import json
import sys
import time
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / '.deps_pa'))
import pandas as pd
from prepare_data import build
from download_criteo_attribution import EXPECTED_SHA, REVISION, SIZE, URL, CHUNK

RAW = ROOT / 'data/raw/new_sources_2026_10_03/dm_venues'
RESEARCH = ROOT / 'research/topvenue_experiments'
OUT = ROOT / 'data/topvenue_instances'
FEATURES = ['cat1', 'cat2', 'cat3']
BLOCK = 500000
OFFSET = 100000
N = OFFSET + 5 * BLOCK


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def freeze(path, value):
    if path.exists():
        assert json.loads(path.read_text()) == value, 'Frozen input plan differs'
    else:
        path.write_text(json.dumps(value, indent=2) + '\n')


def source_prefix():
    """An interim preparation cache; formal publication also requires full SHA/CRC."""
    prefix = RAW / 'criteo_attribution_128MiB.gz.prefix'
    if prefix.exists():
        assert prefix.stat().st_size == 4 * CHUNK
        return prefix
    while True:
        full = RAW / 'criteo_attribution_dataset.tsv.gz'
        if full.exists() and full.stat().st_size == SIZE:
            assert sha(full) == EXPECTED_SHA
            with full.open('rb') as stream:
                prefix.write_bytes(stream.read(4 * CHUNK))
            return prefix
        parts = [RAW / ('attribution_part_%03d' % i) for i in range(4)]
        if all(p.exists() and p.with_suffix('.receipt.json').exists() for p in parts):
            for p in parts:
                receipt = json.loads(p.with_suffix('.receipt.json').read_text())
                assert p.stat().st_size == CHUNK and sha(p) == receipt['sha256']
            with prefix.open('wb') as stream:
                for p in parts:
                    stream.write(p.read_bytes())
            return prefix
        print('Waiting for first four verified source chunks', flush=True)
        time.sleep(5)


def main():
    RESEARCH.mkdir(parents=True, exist_ok=True)
    plan = dict(platform='CriteoAttribution', case='500K-disjoint',
                source_url=URL, upstream_revision=REVISION, source_size=SIZE,
                expected_source_sha256=EXPECTED_SHA,
                source_original_release_venue='AdKDD and TargetAd Workshop 2017, not KDD main',
                verified_main_conference_uses=['Robust Auto-Bidding Strategies for Online Advertising, KDD 2024, DOI 10.1145/3637528.3671729',
                                              'Multi-task Offline Reinforcement Learning for Online Advertising in Recommender Systems, KDD 2025, DOI 10.1145/3711896.3737250'],
                source_unit='One row is one displayed advertising banner, per official release README',
                features=FEATURES, features_anonymized_no_semantics_inferred=True,
                selection_uses_click_conversion_cost_or_method_outcomes=False,
                source_order='Official timestamp order, preserved within each block',
                row_offset=OFFSET, blocks=5, rows_per_block=BLOCK,
                history_rows_per_block=BLOCK//2, allocation_rows_per_block=BLOCK//2,
                seeds=[1,2,3,4,5], loads=[0.5,0.8,1.1],
                offline_contracts=50, online_contracts=100,
                capacity_max_per_node=500, penalty=10000,
                offline_budget_seconds=1000, online_budget_per_query_seconds=60,
                native_gd_contracts=False, native_campaign_ids_used_as_gd_contracts=False,
                observed_supply=True, gd_contracts_targeting_heat_constructed=True,
                source_subsampled_anonymized=True,
                repeated_loads_reuse_same_block=True, traffic_blocks_disjoint=True,
                interim_prefix_used_only_to_overlap_preparation_with_full_download=True,
                formal_export_requires_full_source_lfs_sha256_and_gzip_crc=True)
    plan_path = RESEARCH / 'attribution_preparation_plan.json'
    freeze(plan_path, plan)
    prefix = source_prefix()
    cache = RAW / 'criteo_attribution_context_2.6M.parquet'
    if cache.exists():
        data = pd.read_parquet(cache)
    else:
        data = pd.read_csv(prefix, compression='gzip', sep='\t',
                           usecols=['timestamp'] + FEATURES, dtype='int64', nrows=N)
        assert len(data) == N and data.timestamp.is_monotonic_increasing
        data['source_row'] = range(len(data))
        data.to_parquet(cache, index=False)
    assert len(data) == N and data.source_row.is_unique
    records = list(data[FEATURES].astype(str).itertuples(index=False, name=None))
    profiles = []
    # Feasibility checks use only context counts and do not evaluate any method.
    for seed in plan['seeds']:
        start = OFFSET + (seed - 1) * BLOCK
        frame = data.iloc[start:start+BLOCK]
        contexts = records[start:start+BLOCK]
        hist, supply = Counter(contexts[:BLOCK//2]), Counter(contexts[BLOCK//2:])
        pairs = 0
        for a, b in [(0,1),(0,2),(1,2)]:
            hc = Counter()
            sc = Counter()
            for c, count in hist.items(): hc[c[a],c[b]] += count
            for c, count in supply.items(): sc[c[a],c[b]] += count
            pairs += sum(count >= 40 and 40 <= sc[key] <= .12 * (BLOCK//2)
                         for key, count in hc.items())
        assert pairs >= 150, ('insufficient possible predicates', seed, pairs)
        profiles.append(dict(seed=seed, source_rows=[start,start+BLOCK-1],
                             timestamp_min=int(frame.timestamp.min()), timestamp_max=int(frame.timestamp.max()),
                             eligible_online_two_axis_predicates=pairs,
                             feature_distinct={c: int(frame[c].nunique()) for c in FEATURES}))
    freeze(RESEARCH / 'attribution_feature_feasibility.json', profiles)
    for load in plan['loads']:
        for seed in plan['seeds']:
            start = OFFSET + (seed - 1) * BLOCK
            build('CriteoAttribution', seed, load, rows=records[start:start+BLOCK],
                  out_root=OUT, case=plan['case'], row_offset=start, feature_names=FEATURES)
            name = 'CriteoAttribution_500K-disjoint_load{:03d}_seed{}'.format(round(load*100), seed)
            meta_path = OUT / name / 'instance.json'
            meta = json.loads(meta_path.read_text())
            meta.update(preparation_plan_sha256=sha(plan_path), source_context_sha256=sha(cache),
                        expected_full_source_sha256=EXPECTED_SHA, source_prefix_sha256=sha(prefix),
                        source_revision=REVISION, native_GD_contracts=False,
                        native_campaigns_used_as_GD_contracts=False,
                        input_split='Non-overlapping contiguous blocks from source timestamp order; first 250K rows historical, next 250K rows supply; public source is subsampled')
            meta_path.write_text(json.dumps(meta, indent=2) + '\n')
    audit = dict(prepared_cases=15, used_source_rows=5*BLOCK, source_row_ids_unique=True,
                 disjoint_source_ranges=True, same_rows_reused_across_loads=True,
                 observed_banner_rows_not_bid_opportunities=True,
                 initial_rows_skipped=OFFSET, rows_per_instance=BLOCK,
                 prefix_sha256=sha(prefix), context_cache_sha256=sha(cache),
                 source_full_checksum_required_before_formal_export=True,
                 profiles=profiles, preparation_plan_sha256=sha(plan_path))
    (RESEARCH / 'attribution_data_preparation_audit.json').write_text(json.dumps(audit, indent=2) + '\n')
    print(json.dumps(audit), flush=True)


if __name__ == '__main__':
    main()
