"""Download the complete, pinned official Criteo attribution release."""
import hashlib
import json
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import requests

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / 'data/raw/new_sources_2026_10_03/dm_venues'
RESEARCH = ROOT / 'research/2026-10-03/dm_venues'
REVISION = '904188a63cbad78bee43cd26ff5ee4ac77903986'
URL = ('https://huggingface.co/datasets/criteo/criteo-attribution-dataset/resolve/'
       + REVISION + '/criteo_attribution_dataset.tsv.gz')
SIZE = 653015824
EXPECTED_SHA = '94ac7a465564349bc7ba008602211d5990a3c53cc133abc0aadef61ea2391a98'
CHUNK = 32 * 1024 * 1024


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def download(index):
    start = index * CHUNK
    end = min(start + CHUNK, SIZE) - 1
    path = RAW / ('attribution_part_%03d' % index)
    receipt = path.with_suffix('.receipt.json')
    if path.exists() and receipt.exists():
        record = json.loads(receipt.read_text())
        if path.stat().st_size == end - start + 1 and sha(path) == record['sha256']:
            return record
    for attempt in range(5):
        try:
            response = requests.get(URL, params={'download': 'true', 'part': index,
                                                  'attempt': attempt, 'date': '20261003'},
                                    headers={'Range': 'bytes=%d-%d' % (start, end)},
                                    stream=True, timeout=(30, 90))
            response.raise_for_status()
            assert response.status_code == 206, response.status_code
            expected_range = 'bytes %d-%d/%d' % (start, end, SIZE)
            assert response.headers.get('Content-Range') == expected_range, response.headers
            tmp = path.with_suffix('.part')
            with tmp.open('wb') as stream:
                for block in response.iter_content(1024 * 1024):
                    stream.write(block)
            assert tmp.stat().st_size == end - start + 1, tmp.stat().st_size
            tmp.replace(path)
            record = dict(index=index, start=start, end=end, received_bytes=path.stat().st_size,
                          sha256=sha(path), content_range=expected_range,
                          source_url=URL, upstream_revision=REVISION,
                          etag=response.headers.get('ETag'))
            response.close()
            receipt.write_text(json.dumps(record, indent=2) + '\n')
            print('Downloaded', index, record['received_bytes'], flush=True)
            return record
        except Exception:
            if attempt == 4:
                raise
            time.sleep(min(2 ** attempt, 8))


def main():
    RAW.mkdir(parents=True, exist_ok=True)
    RESEARCH.mkdir(parents=True, exist_ok=True)
    count = (SIZE + CHUNK - 1) // CHUNK
    records = []
    with ThreadPoolExecutor(max_workers=6) as pool:
        futures = [pool.submit(download, index) for index in range(count)]
        for future in as_completed(futures):
            records.append(future.result())
    target = RAW / 'criteo_attribution_dataset.tsv.gz'
    with target.with_suffix('.part').open('wb') as stream:
        for index in range(count):
            with (RAW / ('attribution_part_%03d' % index)).open('rb') as part:
                for block in iter(lambda: part.read(4 * 1024 * 1024), b''):
                    stream.write(block)
    target.with_suffix('.part').replace(target)
    assert target.stat().st_size == SIZE
    assert sha(target) == EXPECTED_SHA, 'Full payload differs from official LFS SHA256'
    probe = RAW / 'criteo_attribution_probe.gz.prefix'
    with target.open('rb') as stream:
        assert stream.read(probe.stat().st_size) == probe.read_bytes()
    manifest = dict(url=URL, revision=REVISION, downloaded_complete=True,
                    bytes=SIZE, sha256=sha(target), matches_official_lfs_sha256=True,
                    initial_probe_matches_full_file=True, gzip_crc_verified=False,
                    parts=sorted(records, key=lambda row: row['index']))
    (RESEARCH / 'attribution_download_manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    for index in range(count):
        (RAW / ('attribution_part_%03d' % index)).unlink()
    print(json.dumps({key: value for key, value in manifest.items() if key != 'parts'}), flush=True)


if __name__ == '__main__':
    main()
