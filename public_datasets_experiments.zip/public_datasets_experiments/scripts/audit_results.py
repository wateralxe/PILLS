"""Recompute every reported objective from saved CSV, independently of runner metrics."""
import argparse
import csv
import json
import math
from collections import defaultdict
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]


def measure(meta,path,online=False,accepted=None):
    supply={s["sid"]:s for s in meta["supplies"]}
    used=defaultdict(int)
    delivered=defaultdict(int)
    with path.open() as f:
        reader=csv.DictReader(f)
        for row in reader:
            sid,j,v=row["SID"],int(row["Demand"]),int(row["Allocated PV"])
            assert v>=0
            assert str(j) in supply[sid]["eligible"],(path,sid,j)
            used[sid]+=v
            delivered[j]+=v
    reward,residual=0.0,0
    for sid,s in supply.items():
        r=s["capacity"]-used[sid]
        assert r>=0,(path,sid)
        residual+=r
        reward+=s["heat"]*r*r
    ud=sum(max(0,d-delivered[j]) for j,d in enumerate(meta["demands"]))
    if online:
        new=sum(delivered[j] for j in range(meta["n_offline"],meta["n_offline"]+meta["n_online"]))
        online_ud=sum(max(0,d-delivered[meta["n_offline"]+j]) for j,d in enumerate(accepted))
        return {"obj":new-10000*(ud+online_ud),"underdelivered_offline":ud,"underdelivered_online":online_ud,
                "allocated_online":new,"residual_final":residual},delivered
    assert all(delivered[j]<=d for j,d in enumerate(meta["demands"]))
    assert all(j<meta["n_offline"] for j in delivered), (path,"offline allocation uses a future contract")
    return {"obj":reward-10000*ud,"ud":ud/sum(meta["demands"]),"underdelivered":ud,"residual":residual},delivered


def main(results_root=None,expected_runs=35):
    results_root=Path(results_root) if results_root else ROOT/"results"
    files=sorted((results_root/"runs").glob("*/result.json"))
    assert len(files)==expected_runs,(len(files),expected_runs)
    checked=0
    for p in files:
        result=json.loads(p.read_text())
        instance_path=Path(result.get("instance_path",str(ROOT/"data/instances"/p.parent.name)))
        meta=json.loads((instance_path/"instance.json").read_text())
        baselines={}
        # Earlier pilot versions append to SCIP's logfile; retain that history
        # and save an unambiguous excerpt for the final reported solve session.
        log=(p.parent/"scip.log").read_text()
        marker="1/1 feasible solution given by solution candidate storage"
        last=log.rfind(marker)
        final=log[last:] if last>=0 else log
        status=result["offline"]["SCIP"]["status"]
        last_status=final[final.rfind("SCIP Status"):]
        assert ("optimal solution found" in last_status) if status=="optimal" else ("time limit reached" in last_status),(p,status,last_status[-500:])
        (p.parent/"scip_final.log").write_text("Final reported solve session; full earlier history, if present, is retained in scip.log.\n"+final)
        for method,row in result["offline"].items():
            measured,totals=measure(meta,p.parent/(method+"_offline.csv"))
            baselines[method]=totals
            for key,value in measured.items():assert math.isclose(value,row[key],rel_tol=1e-10,abs_tol=1e-5),(p,method,key,value,row[key])
            checked+=1
        for method,row in result["online"].items():
            measured,totals=measure(meta,p.parent/(method+"_final.csv"),True,row["gains"])
            for key,value in measured.items():assert value==row[key],(p,method,key,value,row[key])
            for j,v in baselines[method.split("-")[0]].items():assert totals[j]>=v,(p,method,j)
            residual=result["offline"][method.split("-")[0]]["residual"]
            unit=measured["obj"]/residual if residual else None
            assert unit==row["unit"]
            checked+=1
        best=[max(row["gains"][j] for row in result["online"].values()) for j in range(result["n_online"])]
        for method,row in result["online"].items():
            assert row["top"]==sum(g==b for g,b in zip(row["gains"],best))
            assert row["top_nonzero"]==sum(g==b and b>0 for g,b in zip(row["gains"],best))
            assert row["top_strict"]==sum(g==best[j] and sum(other["gains"][j]==best[j] for other in result["online"].values())==1 for j,g in enumerate(row["gains"]))
            assert row["zero_tied_requests"]==sum(b==0 for b in best)
    report={"runs":len(files),"allocation_csv_files_recomputed":checked,
            "checks":"integer/nonnegative/eligibility/capacity/demand; independent offline/online Obj, UD, Unit, Top; final previous deliveries protected",
            "per_step_validation":"runner independently validated all previous deliveries at each arrival"}
    (results_root/"audit.json").write_text(json.dumps(report,indent=2))
    print(json.dumps(report,indent=2))


if __name__=="__main__":
    p=argparse.ArgumentParser()
    p.add_argument("--results-root",type=Path,default=ROOT/"results")
    p.add_argument("--expected-runs",type=int,default=35)
    args=p.parse_args()
    main(args.results_root,args.expected_runs)
