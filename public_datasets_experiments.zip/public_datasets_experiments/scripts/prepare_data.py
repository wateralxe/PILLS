"""Build explicitly semi-synthetic GD workloads from public advertising records."""
import csv
import gzip
import hashlib
import json
import math
import random
import tarfile
import zipfile
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
N_RECORDS = 100000
N_HISTORY = 50000
N_OFFLINE = 50
N_ONLINE = 100
MAX_CAPACITY = 500


def records(platform):
    if platform == "Criteo":
        with tarfile.open(ROOT / "data/raw/criteo_dac_sample.tar.gz", "r:gz") as tar:
            f = tar.extractfile("dac_sample.txt")
            # C5, C8, C17: anonymous categorical attributes, no semantic claim.
            for i, line in enumerate(f):
                if i >= N_RECORDS:
                    break
                fields = line.decode().rstrip("\r\n").split("\t")
                assert len(fields) == 40
                yield tuple(fields[j] or "__MISSING__" for j in [18, 21, 30])
    else:
        with zipfile.ZipFile(ROOT / "data/raw/ipinyou_x1.zip") as z:
            import io
            f = io.TextIOWrapper(z.open("train.csv"))
            for i, row in enumerate(csv.DictReader(f)):
                if i >= N_RECORDS:
                    break
                yield tuple(row[k] for k in ["region", "adexchange", "slotwidth"])


def matches(context, predicate):
    return all(context[int(k)] in values for k, values in predicate.items())


def build(platform, seed, load, rows=None, out_root=None, case=None, row_offset=0, feature_names=None):
    rows = list(records(platform)) if rows is None else rows
    assert len(rows) % 2 == 0, (platform, len(rows))
    historical, evaluation = rows[:len(rows)//2], rows[len(rows)//2:]
    hist = Counter(historical)
    traffic = Counter(evaluation)
    marginals = [Counter(c[k] for c in historical) for k in range(3)]
    contexts = sorted(traffic)
    rng = random.Random(seed)
    predicates = []
    seen = set()
    hist_contexts = sorted(hist)

    def add_predicate(online):
        for _ in range(10000):
            anchor = rng.choice(hist_contexts)
            axes = rng.sample(range(3), 2) if online or rng.random() < 0.5 else [rng.randrange(3)]
            predicate = {str(k): [anchor[k]] for k in sorted(axes)}
            if not online and len(axes) == 1 and rng.random() < 0.5:
                k = axes[0]
                extra = rng.sample(sorted(marginals[k]), min(3, len(marginals[k])))
                predicate[str(k)] = sorted(set(predicate[str(k)] + extra))
            key = json.dumps(predicate, sort_keys=True)
            hist_support = sum(v for c, v in hist.items() if matches(c, predicate))
            test_support = sum(v for c, v in traffic.items() if matches(c, predicate))
            if key not in seen and hist_support >= 40 and test_support >= 40:
                if online and test_support > len(evaluation) * 0.12:
                    continue
                seen.add(key)
                predicates.append(predicate)
                return
        raise RuntimeError("Cannot generate enough distinct supported predicates")

    for j in range(N_OFFLINE + N_ONLINE):
        add_predicate(j >= N_OFFLINE)
    supplies = []
    # Each node is a context bucket with integer traffic count, capped at 500.
    for context in contexts:
        count = traffic[context]
        heat = 0.05 + 0.90 * sum(
            marginals[k][context[k]] / max(marginals[k].values()) for k in range(3)
        ) / 3.0
        eligibility = [str(j) for j, p in enumerate(predicates) if matches(context, p)]
        while count:
            capacity = min(count, MAX_CAPACITY)
            supplies.append({"sid": "u{}_s".format(len(supplies)), "context": list(context),
                             "capacity": capacity, "heat": heat, "eligible": eligibility})
            count -= capacity
    eligible_supply = [sum(s["capacity"] for s in supplies if str(j) in s["eligible"])
                       for j in range(N_OFFLINE)]
    weights = [v * rng.uniform(0.75, 1.25) for v in eligible_supply]
    total_demand = round(load * len(evaluation))
    raw = [total_demand * w / sum(weights) for w in weights]
    demands = [math.floor(v) for v in raw]
    for j in sorted(range(N_OFFLINE), key=lambda j: (-(raw[j] - demands[j]), j))[:total_demand-sum(demands)]:
        demands[j] += 1
    assert min(demands) > 0
    out_root = Path(out_root) if out_root else ROOT / "data/instances"
    case_prefix = (platform+"_"+case) if case else platform
    out = out_root / "{}_load{:03d}_seed{}".format(case_prefix, round(load*100), seed)
    out.mkdir(parents=True, exist_ok=True)
    with (out / "supply.txt").open("w") as f, (out / "heat.txt").open("w") as h:
        for s in supplies:
            user, supply = s["sid"].split("_")
            # A nonexistent sentinel avoids an upstream parser's empty-field bug.
            f.write("{}`{}`{}`{}\n".format(user, supply, s["capacity"], ",".join(s["eligible"]) or "__NONE__"))
            h.write("{}`{}`{:.17g}\n".format(user, supply, s["heat"]))
    (out / "demand.txt").write_text("".join("{}`{}\n".format(j, d) for j, d in enumerate(demands)))
    (out / "online.txt").write_text("".join("{}`0\n".format(j) for j in range(N_OFFLINE, N_OFFLINE+N_ONLINE)))
    metadata = {"platform": platform, "seed": seed, "load": load, "supplies": supplies,
                "demands": demands, "predicates": predicates, "n_offline": N_OFFLINE,
                "n_online": N_ONLINE, "history_rows": len(historical), "evaluation_rows": len(evaluation),
                "input_split": "contiguous block: first half for heat; following half for allocation; row order, not a claim of chronological holdout",
                "row_offset": row_offset, "records_used": len(rows),
                "dataset_case": platform+"-"+(case or "original"),
                "features": feature_names if feature_names is not None else {"Criteo":["C5", "C8", "C17"], "iPinYou":["region", "adexchange", "slotwidth"], "Avazu":["feat_3", "feat_5", "feat_13"],"TencentGR":["user_feat.103","user_feat.104","user_feat.109"]}[platform],
                "heat_formula": "0.05 + 0.90 * mean_k(history_count_k(value)/max_v(history_count_k(v)))",
                "integer_capacity_cap": MAX_CAPACITY, "penalty": 10000,
                "status": "semi-synthetic GD instance; observed public supply, constructed contracts and heat proxy"}
    (out / "instance.json").write_text(json.dumps(metadata, ensure_ascii=False))
    print(out.name, "supply_nodes", len(supplies), "offline_edges",
          sum(sum(int(j) < N_OFFLINE for j in s["eligible"]) for s in supplies), "demand", total_demand, flush=True)


if __name__ == "__main__":
    for platform in ["Criteo", "iPinYou"]:
        for load in [0.5, 0.8, 1.1]:
            for seed in [1, 2, 3, 4, 5]:
                build(platform, seed, load)
