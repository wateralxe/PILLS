"""Verify the unpacked bundle without changing any archived experiment files."""
import argparse
import hashlib
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def sha256(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def check_metrics(root, instances):
    from audit_results import measure
    checked = 0
    for number, item in enumerate(instances, 1):
        run = root / item['run_dir']
        meta = json.loads((root / item['instance_dir'] / 'instance.json').read_text())
        result = json.loads((run / 'result.json').read_text())
        baseline = {}
        for method, row in result['offline'].items():
            values, totals = measure(meta, run / (method + '_offline.csv'))
            baseline[method] = totals
            for key, value in values.items():
                assert math.isclose(value, row[key], rel_tol=1e-10, abs_tol=1e-5), (
                    item['instance'], method, key)
            checked += 1
        best = [max(row['gains'][j] for row in result['online'].values())
                for j in range(result['n_online'])]
        for method, row in result['online'].items():
            values, totals = measure(meta, run / (method + '_final.csv'), True, row['gains'])
            for key, value in values.items():
                assert value == row[key], (item['instance'], method, key)
            for j, delivered in baseline[method.split('-')[0]].items():
                assert totals[j] >= delivered
            residual = result['offline'][method.split('-')[0]]['residual']
            assert row['unit'] == (values['obj'] / residual if residual else None)
            assert row['top'] == sum(g == b for g, b in zip(row['gains'], best))
            assert row['top_nonzero'] == sum(g == b and b > 0
                                            for g, b in zip(row['gains'], best))
            assert row['zero_tied_requests'] == sum(b == 0 for b in best)
            checked += 1
        if number % 5 == 0:
            print('Validated instance %d/%d' % (number, len(instances)), flush=True)
    return checked


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, default=ROOT)
    parser.add_argument('--metrics', action='store_true')
    args = parser.parse_args()
    root = args.root.resolve()
    manifest = json.loads((root / 'MANIFEST.json').read_text())
    for name, expected in manifest['files_sha256'].items():
        assert sha256(root / name) == expected, 'SHA256 mismatch: ' + name
    instances = json.loads((root / 'metadata/instances.json').read_text())['instances']
    checked = check_metrics(root, instances) if args.metrics else 0
    print(json.dumps({'files_sha256_verified': len(manifest['files_sha256']),
                      'instances': len(instances),
                      'allocation_files_recomputed': checked}, ensure_ascii=False))


if __name__ == '__main__':
    main()
